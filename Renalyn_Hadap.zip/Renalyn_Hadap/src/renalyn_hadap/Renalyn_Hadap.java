package renalyn_hadap;

import java.util.Scanner;

public class Renalyn_Hadap {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         Scanner input = new Scanner(System.in);
        int n; 
        
        /**********************************************************
         * CONDITIONAL STATEMENTS 
         **********************************************************/
        
        System.out.println("\nSORT");

        // Enter three numbers
        System.out.print("Enter three integers: ");
        int num1 = input.nextInt();
        int num2 = input.nextInt();
        int num3 = input.nextInt();
        int n1, n2, n3, temp = 0;
        
        n1 = num1;
        n2 = num2;
        n3 = num3;

        // sorting algorithm
        
        if (num1 > num2) {
            temp = num1;
            num1 = num2;
            num2 = temp;
        }

        if (num2 > num3) {
            temp = num2;
            num2 = num3;
            num3 = temp;
        }

        if (num1 > num2) {
            temp = num1;
            num1 = num2;
            num2 = temp;
        }

        input.nextLine(); // eat bread crumbs;

        System.out.printf("Arrange the input from highest to lowest? ");
        char answer = input.nextLine().charAt(0);
        if (Character.toUpperCase(answer) == 'Y') {
            System.out.println("Sorted numbers from highest to lowest:");
            System.out.printf("%d %d %d", num3, num2, num1);
        } else {
            System.out.printf("%d %d %d", n1, n2, n3);
        }

        System.out.println("\nODD OR EVEN");
        System.out.printf("input an integer value for N: ");
        n = input.nextInt();

        if (n >= 2 && n <= 100) {
            System.out.printf("%d - ", n);
            if (n % 2 == 0) {
                System.out.println("EVEN");
            } else {
                System.out.println("ODD");
            }
        } else {
            System.out.printf("Input no. between 2 and 100.");
        }

        System.out.println("\nGROSSPAY CALCULATOR");
        System.out.printf("input days in a week (1-7): ");
        int days_in_a_week = input.nextInt();
        System.out.printf("input number of hours of work: ");
        int number_of_hours = input.nextInt();
        System.out.printf("input rate per hour: ");
        float rate_per_hour = input.nextFloat();

        float gross_pay = 0.0f;

        switch (days_in_a_week) {

            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                gross_pay = number_of_hours * rate_per_hour;
                break;
            case 6:
            case 7:
                gross_pay = number_of_hours * rate_per_hour * 1.5f;
                break;
            default:
                gross_pay = 0.0f;
                break;
        }

        System.out.printf("Your gross pay is %5.2f", gross_pay);
                
        /**********************************************************
         * LOOP CONSTRUCT 
         **********************************************************/

        System.out.println("\nREPEAT N-TIMES - Using DO-WHILE loop");
        System.out.printf("input an integer value for N: ");
        n = input.nextInt();
        do {
            System.out.printf("%d ANG POGI NI SIR JAMES\n", n);
            n = n - 1;
        } while (n > 0);

        System.out.println("\nASCII CODES - using FOR LOOP");
        System.out.println("LOWER CASE | UPPER CASE");
        for (int letter = 0 + 65; letter < 26 + 65; letter++) {
            System.out.printf("%c (%d) | %c (%d)\n",
                    letter + 32, letter + 32, letter, letter);
        }

        System.out.println("\nMULTIPLICATION TABLE");
        System.out.printf("input an integer value for N: ");
        n = input.nextInt();
        int y = 1;
        while (y <= n) {
            int x = 1;
            while (x <= n) {
                System.out.printf("%4d", y * x);
                x = x + 1;
            }
            System.out.println();
            y = y + 1;
        }
        
         
        /**********************************************************
         * ARRAYS
         **********************************************************/

        n = 10; 
        int[] arrInts = new int[n];
        int sum = 0;

        System.out.println("\nSUM AND AVERAGE");
        System.out.printf("input 10 integers to be stored in an array: ");
        for (int i = 0; i < n; i++) {
            arrInts[i] = input.nextInt(); // get integer number
            sum = sum + arrInts[i]; // add them all to sum
        }

        int avg = sum / n; // get the average 
        System.out.printf("sum of integers: %d and it's average: %d",
                sum, avg);

        System.out.println("\nREVERSE ORDER");
        System.out.printf("input 10 integers to be stored in an array: ");

        int[] array1 = new int[n];
        int[] array2 = new int[n];

        for (int i = 0; i < n; i++) {
            array1[i] = input.nextInt(); // get integer number            
            array2[n - 1 - i] = array1[i]; // runs from index (n - 1) - i to 0
        }

        System.out.println("\nelement of array1 and array2:");
        for (int i = 0; i < n; i++) {
            System.out.printf("array1[%d] = %d vs. array2[%d] = %d\n",
                    i, array1[i], i, array2[i]);
        } 
    }
    
}
