package renalyn_hadap.ALL_PROJECTS;
    import java.util.Scanner;
public class GROSSPAY_CALCULATOR {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("\nGROSSPAY CALCULATOR");
        System.out.printf("input days in a week (1-7): ");
        int days_in_a_week = input.nextInt();
        System.out.printf("input number of hours of work: ");
        int number_of_hours = input.nextInt();
        System.out.printf("input rate per hour: ");
        float rate_per_hour = input.nextFloat();

        float gross_pay = 0.0f;

        switch (days_in_a_week) {

            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                gross_pay = number_of_hours * rate_per_hour;
                break;
            case 6:
            case 7:
                gross_pay = number_of_hours * rate_per_hour * 1.5f;
                break;
            default:
                gross_pay = 0.0f;
                break;
        }

        System.out.printf("Your gross pay is %5.2f", gross_pay);
        System.out.println("\t");
    }
}
