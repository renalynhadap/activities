package renalyn_hadap.ALL_PROJECTS;
import java.util.Scanner;
public class MULTIPLICATION_TABLES {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n;
        System.out.println("\nMULTIPLICATION TABLE");
        System.out.printf("input an integer value for N: ");
        n = input.nextInt();
        int y = 1;
        while (y <= n) {
            int x = 1;
            while (x <= n) {
                System.out.printf("%4d", y * x);
                x = x + 1;
            }
            System.out.println();
            y = y + 1;
        }
    }
}
