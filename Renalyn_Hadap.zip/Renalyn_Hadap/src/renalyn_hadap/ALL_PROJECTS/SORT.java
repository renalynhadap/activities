package renalyn_hadap.ALL_PROJECTS;

import java.util.Scanner;
public class SORT {
     
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); 
        /**********************************************************
         * CONDITIONAL STATEMENTS 
         **********************************************************/
        
        System.out.println("\nSORT");

        // Enter three numbers
        System.out.print("Enter three integers: ");
        int num1 = input.nextInt();
        int num2 = input.nextInt();
        int num3 = input.nextInt();
        int n1, n2, n3, temp = 0;
        
        n1 = num1;
        n2 = num2;
        n3 = num3;

        // sorting algorithm
        
        if (num1 > num2) {
            temp = num1;
            num1 = num2;
            num2 = temp;
        }

        if (num2 > num3) {
            temp = num2;
            num2 = num3;
            num3 = temp;
        }

        if (num1 > num2) {
            temp = num1;
            num1 = num2;
            num2 = temp;
        }

        input.nextLine(); // eat bread crumbs;

        System.out.printf("Arrange the input from highest to lowest? ");
        char answer = input.nextLine().charAt(0);
        if (Character.toUpperCase(answer) == 'Y') {
            System.out.println("Sorted numbers from highest to lowest:");
            System.out.printf("%d %d %d", num3, num2, num1);
        } else {
            System.out.printf("%d %d %d", n1, n2, n3);
        }
        System.out.println("\t");
    }
}
